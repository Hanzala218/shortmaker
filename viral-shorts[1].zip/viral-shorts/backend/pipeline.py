"""Processing pipeline: transcribe -> pick moments -> render 9:16 clips with captions."""
import os, re, subprocess
from faster_whisper import WhisperModel

_model = None


def get_model():
    global _model
    if _model is None:
        _model = WhisperModel(os.environ.get("WHISPER_MODEL", "small"),
                              device=os.environ.get("WHISPER_DEVICE", "cpu"),
                              compute_type=os.environ.get("WHISPER_COMPUTE", "int8"))
    return _model


def probe_duration(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                          "-of", "default=nw=1:nk=1", path],
                         capture_output=True, text=True, timeout=60, check=True).stdout.strip()
    return float(out)


# -------------------------------------------------------------- transcribe
def transcribe(path):
    segments, info = get_model().transcribe(path, word_timestamps=True, vad_filter=True)
    segs = []
    for s in segments:
        words = [{"w": w.word.strip(), "s": w.start, "e": w.end} for w in (s.words or []) if w.word.strip()]
        if words:
            segs.append({"start": s.start, "end": s.end, "text": s.text.strip(), "words": words})
    return segs


# ------------------------------------------------------- viral moment picker
HOOKS = re.compile(
    r"\b(secret|never|always|mistake|truth|nobody|everyone|money|free|best|worst|"
    r"warning|shocking|crazy|biggest|why|how|"
    r"raaz|sach|paisa|galti|sabse|kabhi|zaroor|dhyan)\b", re.I)


def score_text(text, duration):
    words = len(text.split())
    score = 0.0
    score += len(HOOKS.findall(text)) * 2.0           # hook words
    score += text.count("?") * 1.5                     # questions keep viewers
    score += text.count("!") * 1.0
    score += len(re.findall(r"\d+", text)) * 0.8       # numbers / stats
    score += min(words / max(duration, 1), 3.5)        # speech density
    return score


def pick_clips(segs, n=5, min_len=20, max_len=55):
    """Slide a window over transcript segments, score it, keep best non-overlapping."""
    cands = []
    for i in range(len(segs)):
        start = segs[i]["start"]
        j = i
        while j < len(segs) and segs[j]["end"] - start <= max_len:
            j += 1
        # window ends at the last segment that still fits
        for k in range(i, j):
            dur = segs[k]["end"] - start
            if dur >= min_len:
                text = " ".join(s["text"] for s in segs[i:k + 1])
                # bonus: opening line is a hook
                bonus = 2.0 if segs[i]["text"].strip().endswith("?") or HOOKS.search(segs[i]["text"]) else 0
                cands.append({"i": i, "k": k, "start": start, "end": segs[k]["end"],
                              "score": score_text(text, dur) + bonus})
    cands.sort(key=lambda c: c["score"], reverse=True)
    chosen = []
    for c in cands:
        if all(c["end"] <= x["start"] or c["start"] >= x["end"] for x in chosen):
            chosen.append(c)
        if len(chosen) >= n:
            break
    chosen.sort(key=lambda c: c["start"])
    return chosen


# ---------------------------------------------------------------- captions
def ass_time(t):
    t = max(t, 0)
    h, m, s = int(t // 3600), int(t % 3600 // 60), t % 60
    return f"{h}:{m:02d}:{s:05.2f}"


def build_ass(words, clip_start, path, group=3):
    """Word-by-word highlighted captions (TikTok style). Active word = yellow."""
    header = (
        "[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\n\n"
        "[V4+ Styles]\n"
        "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,"
        "Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,"
        "Alignment,MarginL,MarginR,MarginV,Encoding\n"
        "Style: Cap,Arial,84,&H00FFFFFF,&H00FFFFFF,&H00000000,&H64000000,"
        "-1,0,0,0,100,100,0,0,1,6,2,2,60,60,520,1\n\n"
        "[Events]\nFormat: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text\n"
    )
    lines = []
    for g in range(0, len(words), group):
        chunk = words[g:g + group]
        for idx, w in enumerate(chunk):
            start = w["s"] - clip_start
            end = (chunk[idx + 1]["s"] if idx + 1 < len(chunk) else w["e"]) - clip_start
            parts = []
            for j, x in enumerate(chunk):
                txt = x["w"].upper().replace("{", "").replace("}", "")
                parts.append(("{\\c&H00D2FF&}" + txt + "{\\c&HFFFFFF&}") if j == idx else txt)
            lines.append(f"Dialogue: 0,{ass_time(start)},{ass_time(end)},Cap,,0,0,0,,{' '.join(parts)}")
    with open(path, "w", encoding="utf-8") as f:
        f.write(header + "\n".join(lines))


def render_clip(job_dir, src, clip, segs, n):
    words = [w for s in segs[clip["i"]:clip["k"] + 1] for w in s["words"]]
    ass_name = f"clip{n}.ass"
    build_ass(words, clip["start"], os.path.join(job_dir, ass_name))
    out = f"clip{n}.mp4"
    dur = clip["end"] - clip["start"]
    cmd = [
        "ffmpeg", "-y", "-ss", f"{clip['start']:.2f}", "-t", f"{dur:.2f}", "-i", src,
        "-vf", f"crop='min(iw,ih*9/16)':ih,scale=1080:1920,subtitles={ass_name}",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "22",
        "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", out,
    ]
    subprocess.run(cmd, cwd=job_dir, check=True, capture_output=True, timeout=900)
    return out


